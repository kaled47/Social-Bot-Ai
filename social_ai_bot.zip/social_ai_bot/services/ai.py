from openai import OpenAI

client = OpenAI(api_key="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")

def generar_respuesta(mensaje: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {
                "role": "system",
                "content": "Eres un asistente de ventas para una agencia de viajes. Responde corto, claro y busca cerrar la venta."
            },
            {
                "role": "user",
                "content": mensaje
            }
        ]
    )

    return response.choices[0].message.content
