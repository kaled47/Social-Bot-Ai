from fastapi import FastAPI
from pydantic import BaseModel
from services.ai import generar_respuesta

app = FastAPI()

# Modelo de datos (estructura del JSON)
class Mensaje(BaseModel):
    mensaje: str

# Endpoint webhook
@app.post("/webhook")
async def webhook(data: Mensaje):
    
    respuesta = generar_respuesta(data.mensaje)

    print("Mensaje recibido:", data.mensaje)
    print("Respuesta IA:", respuesta)

    return {
        "respuesta": respuesta
    }
